---
title:  "Exclude Post from Search Index"
search: false
categories: 
  - Jekyll
---

This post should not appear in the search index because it has the following YAML Front Matter:

```yaml
search: false
```